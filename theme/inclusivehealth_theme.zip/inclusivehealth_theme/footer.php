<footer class="footer">
      <div class="footer__container">
        <ul class="footer__list">
          <li>
            <a href="index.html" class="footer__link">Home</a>
          </li>
          <li>
            <a href="article.html" class="footer__link">Articles</a>
          </li>
          <li>
            <a href="ask-me.html" class="footer__link">Forum</a>
          </li>
          <li>
            <a href="about.html" class="footer__link">About</a>
          </li>
          <li>
            <a
              href="https://instagram.com/inclusive__health?utm_medium=copy_link"
              target="_blank"
              class="footer__social-link"
            >
              <i class="bx bxl-instagram"></i>
            </a>
          </li>
        </ul>
      </div>
    </footer>

    <?php 
      wp_footer();
    ?>
